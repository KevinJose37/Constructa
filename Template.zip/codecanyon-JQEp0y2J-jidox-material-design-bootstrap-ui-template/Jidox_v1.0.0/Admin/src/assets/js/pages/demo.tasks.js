/*
Template Name: Jidox - Responsive Bootstrap 5 Admin Dashboard
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Task Js
*/


// Bubble theme
var quill = new Quill('#bubble-editor', {
    theme: 'bubble'
});